# Review brief - Lada Panas bilge monitor, board Rev C.5 (2026-10-31)

You are asked to review a **designed but not yet built or ordered** PCB. Please read this file, then `02_design_documents/HOLISTIC_REVIEW_revC3.md` (the designer's own review: findings, open items, questions for you), and then look at the files you find useful. Be critical: the design and the first review were made by the same AI, so independent eyes are the point. Report anything that would stop the board working, damage it or the boat, or cost a respin, and rank your findings (High / Medium / Low).

## What the board is
A 100 x 100 mm, 2-layer board for a boat's dry helm compartment (behind a Raymarine Axiom MFD) that
- monitors three bilge-pump "running" signals and one high-water float switch (12 V signals, 8-16 V = active),
- drives an external warning light and an external buzzer (switched +12 V, high side),
- reports on **NMEA 2000** through an **isolated CAN transceiver** (CA-IS3050G, 5 kVrms) so a fault cannot reach the bus devices,
- carries an on-board barometric pressure/temperature sensor (MS5637), two LEDs, a mute button,
- plugs in an **ESP32-S3-DevKitC-1 (clone) dev board** on two 1x22 sockets and breaks out all 44 dev-board pins to numbered solder pads.
A hard-wired path turns both outputs on when the float input is active, without the ESP32.
Power: boat 12 V battery (10-15 V normal, up to ~16 V charging, 3 A external fuse), reverse-polarity P-FET, bidirectional TVS, resettable fuse, 5 V buck (AP63205) to the dev board's 5V pin; the dev board makes 3.3 V. NMEA 2000 side is powered from the bus (9-16 V) through SS14 + L78L05 and is galvanically isolated from the rest.
Firmware is not written yet.

## Ordering plan
JLCPCB only: PCB + Economic assembly of 5 boards (top side SMT, terminals and sockets soldered by JLCPCB), about US$90 excluding shipping and dev boards. The order has NOT been placed. A JLCPCB quote draft exists (not in the cart).

## Where things are
| Folder | Contents |
|---|---|
| 01_read_first | this brief |
| 02_design_documents | design decisions, dev-board pin map, **HOLISTIC_REVIEW_revC3.md**, quotes/sensor comparison |
| 03_circuit_netlist_bom | **CIRCUIT_DESCRIPTION.md** (every part, pin and net, per block), netlist by net, parts list, JLCPCB BOM and placement file, full BOM with prices |
| 04_kicad | routed board (`bilge_n2k_revC_routed.kicad_pcb`, KiCad 10), project file, unrouted placement, custom MS5637 footprint. There is **no schematic drawing**: the netlist is generated from Python (`09_generator_source/design_revC.py`) and the board is built from it |
| 05_fabrication | Gerber/drill zip as sent to JLCPCB, unzipped copies, assembly and bottom-copper PDFs |
| 06_renders | 3D renders top/bottom/angled |
| 07_datasheets | the datasheets the author could read, and a list of those he could not |
| 08_verification | DRC report, pad/net check, isolation check, track/via/drill statistics, JLCPCB tooling findings |
| 09_generator_source | the Python/shell pipeline (netlist -> board -> autoroute -> DRC -> export) |

## Known facts that look odd but are intended
- Placement-file rotations differ from KiCad's for SOT-23, TSOT-23-6 and SOIC-8 parts (JLCPCB library offsets, verified in their viewer).
- BR1, BR2, PW1 are bare pad rows (no part); the BOM lists 23 lines / 77 placed parts; the dev board itself is not on the BOM.
- IN5 was dropped; the board has four inputs (IN1-IN3 pump sense, IN4 = float).
- Only the CAN side is isolated; the 12 V side is non-isolated by design (owner's choice for cost).
- The final DRC runs at 0.18 mm clearance while the autorouter works to 0.20 mm (JLCPCB's limit is 0.127 mm).

## Please focus on
1. The questions in section 6 of HOLISTIC_REVIEW_revC3.md.
2. Anything that disagrees between the netlist (03), the board (04) and the datasheets (07).
3. Any item the author marked unverified (O2-O3, and the DORABO terminal in F6) that you can close.
