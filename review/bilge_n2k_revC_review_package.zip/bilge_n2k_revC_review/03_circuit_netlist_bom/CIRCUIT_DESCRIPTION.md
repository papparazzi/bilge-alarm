# Circuit description (generated from gen/design_revC.py, the single source of the netlist)

Every part below with its footprint, its pins and the net each pin sits on. Nets named `J1_Pn`/`J3_Pn` are unused dev-board pins that only go to the breakout pad rows.


## Block: MCU

| Ref | Part (MPN) | Footprint | Pin -> net | Note |
|---|---|---|---|---|
| BR1 | (no part: pads/hole only) | PinHeader_1x22_P2.54mm_Vertical | 22 pins, see netlist file | breakout pads for the UNUSED dev-board J1 pins + its 3V3/5V/GND pins |
| BR2 | (no part: pads/hole only) | PinHeader_1x22_P2.54mm_Vertical | 22 pins, see netlist file | breakout pads for the unused dev-board J3 pins + GND + I2C SDA/SCL |
| C9 | CC0603KRX7R9BB104 | C_0603_1608Metric | 1:+3V3, 2:GND | 3V3 decoupling for U4 side |
| D2 | KT-0603R | LED_0603_1608Metric | 1:GND, 2:LED_STAT_A | status LED red (cathode pin 1); same part as D3 so it is JLCPCB Basic |
| D3 | KT-0603R | LED_0603_1608Metric | 1:GND, 2:LED_ALM_A | alarm LED red (cathode pin 1) |
| HDR1 | HC-PM254-8.5H-1x22PZ | PinSocket_1x22_P2.54mm_Vertical | 22 pins, see netlist file | dev board J1: 1,2 3V3 / 3 RST / 4-7 GPIO4-7 / 8 GPIO15 / 9 GPIO16 / 10 GPIO17 / 11 GPIO18 / 12 GPIO8 / 13 GPIO3 / 14 GPIO46 / 15 GPIO9 / 16 GPIO10 / 17 GPIO11 / 18 GPIO12 / 19 GPIO13 / 20 GPIO14 / 21 5V / 22 G |
| HDR2 | HC-PM254-8.5H-1x22PZ | PinSocket_1x22_P2.54mm_Vertical | 22 pins, see netlist file | dev board J3: 1 G / 2 TX / 3 RX / 4 GPIO1 / 5 GPIO2 / 6-13 GPIO42,41,40,39,38,37,36,35 / 14 GPIO0 / 15 GPIO45 / 16 GPIO48 / 17 GPIO47 / 18 GPIO21 / 19 GPIO20 / 20 GPIO19 / 21,22 G |
| PW1 | (no part: pads/hole only) | PinHeader_1x03_P2.54mm_Vertical | 1:+3V3, 2:DEV_5V, 3:GND | power pads for a sensor: 3V3, 5V, GND |
| R5 | 0603WAF4700T5E | R_0603_1608Metric | 1:LED_STAT, 2:LED_STAT_A | LED series (about 3 mA) |
| R6 | 0603WAF4700T5E | R_0603_1608Metric | 1:LED_ALM, 2:LED_ALM_A | LED series (about 3 mA) |
| R7 | 0603WAF1002T5E | R_0603_1608Metric | 1:+3V3, 2:BTN_MUTE | MUTE pull-up |
| SW3 | TS-1187A-B-A-B | SW_Push_1P1T_XKB_TS-1187A | 1:BTN_MUTE, 2:GND | MUTE (long press = lamp/buzzer test); RESET and BOOT are the dev board's own buttons |

## Block: Power

| Ref | Part (MPN) | Footprint | Pin -> net | Note |
|---|---|---|---|---|
| C1 | CL21A106KAYNNNE | C_0805_2012Metric | 1:VIN, 2:GND | buck CIN |
| C2 | CL21A106KAYNNNE | C_0805_2012Metric | 1:VIN, 2:GND | buck CIN |
| C3 | CL21A106KAYNNNE | C_0805_2012Metric | 1:VIN, 2:GND | buck CIN |
| C4 | CC0603KRX7R9BB104 | C_0603_1608Metric | 1:VIN, 2:GND | HF at VIN pin |
| D1 | SMBJ15CA | D_SMB | 1:VBAT_IN, 2:GND | supply TVS, bidirectional |
| F1 | SMD1812-200-24 | Fuse_1812_4532Metric | 1:VBAT_IN, 2:VFUSED | board PPTC 2 A hold, 4 A trip (1.5 A hold derated too far at 50 C behind the MFD) |
| J1 | DB127S-5.08-2P-GN-S | TerminalBlock_Phoenix_MKDS-1,5-2-5.08_1x02_P5.08mm_Horizontal | 1:VBAT_IN, 2:GND | 12 V IN (external 3 A fuse required) |
| Q1 | AO3401A | SOT-23 | 1:Q1_G, 2:VIN, 3:VFUSED | reverse-polarity P-FET (pin 1 G, 2 S, 3 D) |
| R1 | 0603WAF4702T5E | R_0603_1608Metric | 1:VIN, 2:Q1_G | Q1 gate divider top |
| R2 | 0603WAF1003T5E | R_0603_1608Metric | 1:Q1_G, 2:GND | Q1 gate divider bottom |

## Block: Buck

| Ref | Part (MPN) | Footprint | Pin -> net | Note |
|---|---|---|---|---|
| C5 | CC0603KRX7R9BB104 | C_0603_1608Metric | 1:BST, 2:SW | bootstrap |
| C6 | CL21A226MAQNNNE | C_0805_2012Metric | 1:+5V, 2:GND | buck COUT (22 uF per AP63205 datasheet) |
| C7 | CL21A226MAQNNNE | C_0805_2012Metric | 1:+5V, 2:GND | buck COUT (22 uF per AP63205 datasheet) |
| C8 | CL21A226MAQNNNE | C_0805_2012Metric | 1:+5V, 2:GND | buck COUT (22 uF per AP63205 datasheet) |
| D8 | SS14 | D_SMA | 1:DEV_5V, 2:+5V | +5V -> dev-board 5V pin (cathode = DEV_5V); blocks back-feed from the dev-board USB port |
| L1 | SRN6045TA-4R7M | L_Bourns_SRN6045TA | 1:SW, 2:+5V | 4.7 uH: confirmed against AP63205 datasheet DS41326 Table 3 (5 V out) |
| R3 | 0603WAF1003T5E | R_0603_1608Metric | 1:VIN, 2:EN_BUCK | EN divider top |
| R4 | 0603WAF4702T5E | R_0603_1608Metric | 1:EN_BUCK, 2:GND | EN divider bottom (EN = 0.32 VIN) |
| U1 | AP63205WU-7 | TSOT-23-6 | 1:+5V, 2:EN_BUCK, 3:VIN, 4:GND, 5:SW, 6:BST | 5 V buck; pin 1 = FB tied to output (AP63205 datasheet Fig. 21) |

## Block: Inputs

| Ref | Part (MPN) | Footprint | Pin -> net | Note |
|---|---|---|---|---|
| C10 | CC0603KRX7R9BB104 | C_0603_1608Metric | 1:IN1_A, 2:GND | IN1 filter |
| C11 | CC0603KRX7R9BB104 | C_0603_1608Metric | 1:IN2_A, 2:GND | IN2 filter |
| C12 | CC0603KRX7R9BB104 | C_0603_1608Metric | 1:IN3_A, 2:GND | IN3 filter |
| C13 | CC0603KRX7R9BB104 | C_0603_1608Metric | 1:IN4_A, 2:GND | IN4 filter |
| C14 | CC0603KRX7R9BB104 | C_0603_1608Metric | 1:VSENSE_A, 2:GND | VSENSE filter |
| J2 | DB127S-5.08-4P-GN-S | TerminalBlock_Phoenix_MKDS-1,5-4-5.08_1x04_P5.08mm_Horizontal | 1:IN1_RAW, 2:IN2_RAW, 3:IN3_RAW, 4:IN4_RAW | 1-3 pump run, 4 high-water float (8-16 V = active); the 5th (aux) input was dropped in this revision, its divider R16/R17/C14 is a spare |
| R8 | 0603WAF1003T5E | R_0603_1608Metric | 1:IN1_RAW, 2:IN1_A | IN1 divider top |
| R9 | 0603WAF2702T5E | R_0603_1608Metric | 1:IN1_A, 2:GND | IN1 divider bottom (12 V -> 2.55 V) |
| R10 | 0603WAF1003T5E | R_0603_1608Metric | 1:IN2_RAW, 2:IN2_A | IN2 divider top |
| R11 | 0603WAF2702T5E | R_0603_1608Metric | 1:IN2_A, 2:GND | IN2 divider bottom (12 V -> 2.55 V) |
| R12 | 0603WAF1003T5E | R_0603_1608Metric | 1:IN3_RAW, 2:IN3_A | IN3 divider top |
| R13 | 0603WAF2702T5E | R_0603_1608Metric | 1:IN3_A, 2:GND | IN3 divider bottom (12 V -> 2.55 V) |
| R14 | 0603WAF1003T5E | R_0603_1608Metric | 1:IN4_RAW, 2:IN4_A | IN4 divider top |
| R15 | 0603WAF2702T5E | R_0603_1608Metric | 1:IN4_A, 2:GND | IN4 divider bottom (12 V -> 2.55 V) |
| R16 | 0603WAF1003T5E | R_0603_1608Metric | 1:VIN, 2:VSENSE_A | VSENSE divider top |
| R17 | 0603WAF2702T5E | R_0603_1608Metric | 1:VSENSE_A, 2:GND | VSENSE divider bottom |

## Block: NMEA2000

| Ref | Part (MPN) | Footprint | Pin -> net | Note |
|---|---|---|---|---|
| C15 | CL21A106KAYNNNE | C_0805_2012Metric | 1:NET_SP, 2:NET_C | LDO input |
| C16 | CL21A106KAYNNNE | C_0805_2012Metric | 1:+5V_ISO, 2:NET_C | LDO output |
| C17 | CC0603KRX7R9BB104 | C_0603_1608Metric | 1:+5V_ISO, 2:NET_C | VCC2 bypass at U4 |
| C18 | CC0603KRX7R9BB104 | C_0603_1608Metric | 1:+3V3, 2:GND | VCC1 bypass at U4 |
| D6 | SMBJ15CA | D_SMB | 1:NET_S, 2:NET_C | bus-side TVS |
| D7 | SS14 | D_SMA | 1:NET_SP, 2:NET_S | NET-S reverse protection (KiCad D_SMA: pin 1 = cathode = NET_SP, pin 2 = anode = NET_S) |
| J4 | DB127S-5.08-4P-GN-S | TerminalBlock_Phoenix_MKDS-1,5-4-5.08_1x04_P5.08mm_Horizontal | 1:NET_S, 2:NET_C, 3:CANH_J, 4:CANL_J | NMEA 2000: 1 NET-S (+12 V), 2 NET-C (V-), 3 CAN-H, 4 CAN-L; shield not connected on board |
| R24 | 0603WAF1002T5E | R_0603_1608Metric | 1:+3V3, 2:CAN_TX | TXD pull-up: recessive during reset/boot |
| U3 | L78L05ABUTR | SOT-89-3 | 1:+5V_ISO, 2:NET_C, 3:NET_SP | bus-side 5 V (pin 1 OUT, 2 GND, 3 IN) |
| U4 | CA-IS3050G | SOIC-8_7.5x5.85mm_P1.27mm | 1:+3V3, 2:CAN_RX, 3:CAN_TX, 4:GND, 5:NET_C, 6:CANL_J, 7:CANH_J, 8:+5V_ISO | NOTE pin order differs from ISO1042: pin 2 = RXD, pin 3 = TXD |

## Block: Sensor

| Ref | Part (MPN) | Footprint | Pin -> net | Note |
|---|---|---|---|---|
| C19 | CC0603KRX7R9BB104 | C_0603_1608Metric | 1:+3V3, 2:GND | MS5637 VDD bypass (datasheet: 100 nF at the VDD pin) |
| R25 | 0603WAF5101T5E | R_0603_1608Metric | 1:+3V3, 2:I2C_SDA | I2C pull-up |
| R26 | 0603WAF5101T5E | R_0603_1608Metric | 1:+3V3, 2:I2C_SCL | I2C pull-up |
| U5 | MS563702BA03-50 | MS5637-02BA03_QFN-4_3x3mm | 1:+3V3, 2:I2C_SDA, 3:I2C_SCL, 4:GND | pin 1 VDD, 2 SDA, 3 SCL, 4 GND (pads seen from above: pin 1 top-left, 2 bottom-left, 3 bottom-right, 4 top-right) |

## Block: Outputs

| Ref | Part (MPN) | Footprint | Pin -> net | Note |
|---|---|---|---|---|
| D4 | SS14 | D_SMA | 1:LIGHT_OUT, 2:GND | flyback across the load (cathode = switched +12 V, anode = GND) |
| D5 | SS14 | D_SMA | 1:BUZZ_OUT, 2:GND | flyback across the load (cathode = switched +12 V, anode = GND) |
| J3 | DB127S-5.08-4P-GN-S | TerminalBlock_Phoenix_MKDS-1,5-4-5.08_1x04_P5.08mm_Horizontal | 1:LIGHT_OUT, 2:GND, 3:BUZZ_OUT, 4:GND | 1 LIGHT+ (switched +12 V), 2 GND, 3 BUZZER+ (switched +12 V), 4 GND |
| Q2 | AO3400A | SOT-23 | 1:L_G, 2:GND, 3:L_PD | light gate-driver N-FET (pin 1 G, 2 S, 3 D) |
| Q3 | AO3400A | SOT-23 | 1:B_G, 2:GND, 3:B_PD | buzzer gate-driver N-FET (pin 1 G, 2 S, 3 D) |
| Q4 | AO3400A | SOT-23 | 1:HW_G, 2:GND, 3:L_PD | hardware high-water -> light (wired-OR with Q2) |
| Q5 | AO3400A | SOT-23 | 1:HW_G, 2:GND, 3:B_PD | hardware high-water -> buzzer (wired-OR with Q3) |
| Q6 | AO3401A | SOT-23 | 1:L_PG, 2:VIN, 3:LIGHT_OUT | light high-side P-FET (pin 1 G, 2 S, 3 D) |
| Q7 | AO3401A | SOT-23 | 1:B_PG, 2:VIN, 3:BUZZ_OUT | buzzer high-side P-FET (pin 1 G, 2 S, 3 D) |
| R18 | 0603WAF1001T5E | R_0603_1608Metric | 1:LIGHT_CTL, 2:L_G | gate series |
| R19 | 0603WAF1003T5E | R_0603_1608Metric | 1:L_G, 2:GND | gate pull-down (OFF in reset) |
| R20 | 0603WAF1001T5E | R_0603_1608Metric | 1:BUZZ_CTL, 2:B_G | gate series |
| R21 | 0603WAF1003T5E | R_0603_1608Metric | 1:B_G, 2:GND | gate pull-down (OFF in reset) |
| R22 | 0603WAF1003T5E | R_0603_1608Metric | 1:IN4_RAW, 2:HW_G | R_HW1 - DNP to disable the hardware bypass |
| R23 | 0603WAF4702T5E | R_0603_1608Metric | 1:HW_G, 2:GND | R_HW2 - HW gate divider (12 V -> 3.8 V; 29 V surge -> 9.3 V < 12 V VGS max) |
| R27 | 0603WAF2202T5E | R_0603_1608Metric | 1:VIN, 2:L_PG | P-FET gate pull-up 22 k (off by default); /VGS/ = VIN x 22/(22+47) = 0.32 VIN when driven |
| R28 | 0603WAF4702T5E | R_0603_1608Metric | 1:L_PG, 2:L_PD | P-FET gate divider bottom 47 k |
| R29 | 0603WAF2202T5E | R_0603_1608Metric | 1:VIN, 2:B_PG | P-FET gate pull-up 22 k (off by default); /VGS/ = VIN x 22/(22+47) = 0.32 VIN when driven |
| R30 | 0603WAF4702T5E | R_0603_1608Metric | 1:B_PG, 2:B_PD | P-FET gate divider bottom 47 k |

## Block: Mech

| Ref | Part (MPN) | Footprint | Pin -> net | Note |
|---|---|---|---|---|
| H1 | (no part: pads/hole only) | MountingHole_3.2mm_M3 |  | M3 mounting hole (position TBD from enclosure) |
| H2 | (no part: pads/hole only) | MountingHole_3.2mm_M3 |  | M3 mounting hole (position TBD from enclosure) |
| H3 | (no part: pads/hole only) | MountingHole_3.2mm_M3 |  | M3 mounting hole (position TBD from enclosure) |
| H4 | (no part: pads/hole only) | MountingHole_3.2mm_M3 |  | M3 mounting hole (position TBD from enclosure) |
